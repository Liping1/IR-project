## Define and run test suite.

testsuite.simuassets <- defineTestSuite ("simuassets", file.path("/Users/xiaofengqi"),
                                         testFileRegexp = "IRprojectTest.R",)
testResult  <- runTestSuite(testsuite.simuassets)
printTextProtocol(testResult)
