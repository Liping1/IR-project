## Inspect code:

library(RUnit)


simuclaims_a_year <- function(n, alpha, beta){
  u <-  runif(n) ## generate n random numbers from uniform distribution.
  X <- beta*(exp(-log(u)/alpha)-1) ## caculate X using inversion method.
  return (X)  
}


simuassets <- function(ns, Z0, premium_year_customer, n, p, ny, alpha, beta){
  assets <- c()  ## simulated assets over ny years.
  profits <- c() ## simulated profits over ny years.
  premiums <- premium_year_customer*n ## premiums paid by n customs in a year.
  for(i in 1:ns){
     claims <- simuclaims_a_year (n*p, alpha, beta) # simulated claims in year one.
     z <- c() ## assets at the end of eack year.
     pro <- c()  ## profits at the end of each year.
     z[1] <- max(Z0 + premiums - sum(claims),0) ## assets at the end of year 1.
     if(z[1]>Z0){
          pro[1] <-z[1]-Z0 ## profits at the end of year 1.
          z[1] <- Z0
          } else {pro[1] <- 0
            }
    
     for (t in 2:ny){
         claims  <- simuclaims_a_year(n*p, alpha, beta)  ## simulated claims at the end of year t.
         if(z[t-1] > 0){
               z[t] <- max(z[t-1]+premiums-claims,0)  
               if(z[t]>Z0){
                      pro[t] <-z[t]-Z0 ## profits at the end of year t.
                      z[t] <- Z0       ## assets at teh end of year t.
               } else {pro[t] <- 0}
         } else if (z[t-1]==0){
                      z[t] <- 0
         }
     }
     assets <- rbind(assets,c(Z0,z)) ## collect of simulated assets each year
     profits <- rbind(profits,pro)   ## collect of simulated profits each year
  }
  
 
  k <- ifelse (assets[,ny]==0.0, 1, 0) ## number of times going bust
  
  p_gobust <- sum(k)/ns  ## probability of going bust 
  cat("The probability of going bust is", p_gobust, "\n")
  
  expected_assets_ny <- mean(assets[,ny]) ## average of assets at the end of ny years
  cat("The expected assets at the end of", ny, "years is", expected_assets_ny,"\n")      
  con95assetsl <- expected_assets_ny-1.96*sqrt(var(assets[,ny])/ns)
  con95assetsu <- expected_assets_ny+1.96*sqrt(var(assets[,ny])/ns)
  con95assets <- c(con95assetsl,con95assetsu)  ## 95% confidence interval for the assets at the end of ny years
  cat("The 95% confidence interval for assets is", con95assets,"\n")      
  
  profits_ny <- c()
  for(i in 1:ns){
     profits_ny[i] <- sum(profits[i,])
  }  ## total profits over ny years for each simulation
  expected_profits <- mean(profits_ny)  ## average of total profits from ns simulations
  cat("The expected profits over the", ny, "years is", expected_profits,"\n") 
  con95profitsl <- expected_profits-1.96*sqrt(var(profits_ny)/ns)
  con95profitsu <- expected_profits+1.96*sqrt(var(profits_ny)/ns)
  con95profits <- c(con95profitsl,con95profitsu)  ## 95% confidence interval for profits over ny years
  cat("The 95% confidence interval for profits is", con95profits,"\n")                
         
}


track  <- tracker() 
track$init()

resClaims <- inspect(simuclaims_a_year(100,3,100000), track = track)
resAssets <- inspect(simuassets(10, 1000000, 5500, 100, 0.1, 5, 3, 100000), track = track)
resTrack <- track$getTrackInfo()
printHTML.trackInfo(resTrack)



